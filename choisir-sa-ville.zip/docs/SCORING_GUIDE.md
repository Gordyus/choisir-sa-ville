# Scoring Guide

- Scores normalisés
- Présentation utilisateur sur 5 étoiles
- Calculs transparents et explicables
