# Data Contract

Les données exposées par l’API sont :
- versionnées
- documentées
- stables

Toute modification implique :
- migration
- mise à jour doc
