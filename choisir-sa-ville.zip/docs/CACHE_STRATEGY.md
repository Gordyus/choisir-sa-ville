# Cache Strategy

Objectif : réduire les calculs coûteux et appels DB.

- Cache en mémoire en local
- Interface Cache abstraite
- Implémentation Redis/KV possible en prod
- TTL explicite par use-case
