# Project Guides

## Philosophie
- Simplicité > abstraction prématurée
- Lisibilité > micro-optimisation
- Portabilité > vendor lock-in
