# Import Pipeline

- Données publiques (INSEE, IGN, etc.)
- Import via scripts dédiés
- Jamais depuis l’API runtime
- Traçabilité des sources obligatoire
