# Git Commit Guidelines

See full commit rules inside.
