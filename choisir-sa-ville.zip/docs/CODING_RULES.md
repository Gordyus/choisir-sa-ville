# Coding Rules

- TypeScript strict
- Pas de logique métier dans les routes
- Validation Zod systématique
- Pas d’accès DB direct depuis l’API
